import React from "react";
import Bookings from "../Components/Bookings";

function Show() {
  return (
    <div>
      <Bookings />
    </div>
  );
}

export default Show;

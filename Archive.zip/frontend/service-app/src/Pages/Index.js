import React from 'react'
import MeetingRooms from '../Components/MeetingRooms'

function Index() {
  return (
    <div>
      <MeetingRooms />
    </div>
  )
}

export default Index